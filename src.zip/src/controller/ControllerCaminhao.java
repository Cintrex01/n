package controller;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import model.Caminhao;

public class ControllerCaminhao extends Controller {

    @Override
    public void Caminho() {
        path = "C:\\Docs";
        fileName = "Caminhoes.bin"; 
    }

    public ArrayList<Caminhao> exibirCaminhoes() {
        ArrayList<Caminhao> dados = new ArrayList<>();

        leituraArquivo();

        try (DataInputStream dis = new DataInputStream(new FileInputStream(arquivo))) {
            while (dis.available() > 0) {
                String placa = dis.readUTF();
                String marca = dis.readUTF();
                String modelo = dis.readUTF();
                int cargaMaxima = dis.readInt();
                dados.add(new Caminhao(placa, marca, modelo, cargaMaxima));
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return dados;
    }

    public boolean caminhaoExiste(String placa) {
        for (Caminhao caminhao : exibirCaminhoes()) {
            if (caminhao.getPlaca().equals(placa)) {
                return true;
            }
        }
        return false;
    }

    public void cadastrarCaminhao(Caminhao caminhao) {
        escritaArquivo();

        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(arquivo, true))) {
            dos.writeUTF(caminhao.getPlaca());
            dos.writeUTF(caminhao.getMarca());
            dos.writeUTF(caminhao.getModelo());
            dos.writeInt(caminhao.getCargaMaxima());
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public boolean alterarCaminhao(String placaAntiga, String placaNova, String marcaNova, String modeloNovo, int cargaMaximaNova) {
        ArrayList<Caminhao> temporario = new ArrayList<>();

        leituraArquivo();

        try (DataInputStream dis = new DataInputStream(new FileInputStream(arquivo))) {
            while (dis.available() > 0) {
                String placa = dis.readUTF();
                String marca = dis.readUTF();
                String modelo = dis.readUTF();
                int cargaMaxima = dis.readInt();

                if (placaAntiga.equals(placa)) {
                    temporario.add(new Caminhao(placaNova, marcaNova, modeloNovo, cargaMaximaNova));
                } else {
                    temporario.add(new Caminhao(placa, marca, modelo, cargaMaxima));
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        escritaArquivoNovo();

        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(arquivo))) {
            for (Caminhao caminhao : temporario) {
                dos.writeUTF(caminhao.getPlaca());
                dos.writeUTF(caminhao.getMarca());
                dos.writeUTF(caminhao.getModelo());
                dos.writeInt(caminhao.getCargaMaxima());
            }
            return true;
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return false;
    }

    public boolean excluirCaminhao(String placa) {
        ArrayList<Caminhao> temporario = new ArrayList<>();

        leituraArquivo();

        try (DataInputStream dis = new DataInputStream(new FileInputStream(arquivo))) {
            while (dis.available() > 0) {
                String placaAtual = dis.readUTF();
                String marca = dis.readUTF();
                String modelo = dis.readUTF();
                int cargaMaxima = dis.readInt();

                if (!placa.equals(placaAtual)) {
                    temporario.add(new Caminhao(placaAtual, marca, modelo, cargaMaxima));
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        escritaArquivoNovo();

        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(arquivo))) {
            for (Caminhao caminhao : temporario) {
                dos.writeUTF(caminhao.getPlaca());
                dos.writeUTF(caminhao.getMarca());
                dos.writeUTF(caminhao.getModelo());
                dos.writeInt(caminhao.getCargaMaxima());
            }
            return true;
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return false;
    }
}