package controller;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import model.Moto;

public class ControllerMoto extends Controller {

    @Override
    public void Caminho() {
        path = "C:\\Docs";
        fileName = "Motos.bin"; 
    }

    public ArrayList<Moto> exibirMotos() {
        ArrayList<Moto> dados = new ArrayList<>();

        leituraArquivo();

        try (DataInputStream dis = new DataInputStream(new FileInputStream(arquivo))) {
            while (dis.available() > 0) {
                String placa = dis.readUTF();
                String marca = dis.readUTF();
                String modelo = dis.readUTF();
                int ano = dis.readInt();
                dados.add(new Moto(placa, marca, modelo, ano));
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return dados;
    }

    public boolean motoExiste(String placa) {
        for (Moto moto : exibirMotos()) {
            if (moto.getPlaca().equals(placa)) {
                return true;
            }
        }
        return false;
    }

    public void cadastrarMoto(Moto moto) {
        escritaArquivo();

        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(arquivo, true))) {
            dos.writeUTF(moto.getPlaca());
            dos.writeUTF(moto.getMarca());
            dos.writeUTF(moto.getModelo());
            dos.writeInt(moto.getAno());
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public boolean alterarMoto(String placaAntiga, String placaNova, String marcaNova, String modeloNovo, int anoNovo) {
        ArrayList<Moto> temporario = new ArrayList<>();

        leituraArquivo();

        try (DataInputStream dis = new DataInputStream(new FileInputStream(arquivo))) {
            while (dis.available() > 0) {
                String placa = dis.readUTF();
                String marca = dis.readUTF();
                String modelo = dis.readUTF();
                int ano = dis.readInt();

                if (placaAntiga.equals(placa)) {
                    temporario.add(new Moto(placaNova, marcaNova, modeloNovo, anoNovo));
                } else {
                    temporario.add(new Moto(placa, marca, modelo, ano));
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        escritaArquivoNovo();

        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(arquivo))) {
            for (Moto moto : temporario) {
                dos.writeUTF(moto.getPlaca());
                dos.writeUTF(moto.getMarca());
                dos.writeUTF(moto.getModelo());
                dos.writeInt(moto.getAno());
            }
            return true;
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return false;
    }

    public boolean excluirMoto(String placa) {
        ArrayList<Moto> temporario = new ArrayList<>();

        leituraArquivo();

        try (DataInputStream dis = new DataInputStream(new FileInputStream(arquivo))) {
            while (dis.available() > 0) {
                String placaAtual = dis.readUTF();
                String marca = dis.readUTF();
                String modelo = dis.readUTF();
                int ano = dis.readInt();

                if (!placa.equals(placaAtual)) {
                    temporario.add(new Moto(placaAtual, marca, modelo, ano));
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        escritaArquivoNovo();

        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(arquivo))) {
            for (Moto moto : temporario) {
                dos.writeUTF(moto.getPlaca());
                dos.writeUTF(moto.getMarca());
                dos.writeUTF(moto.getModelo());
                dos.writeInt(moto.getAno());
            }
            return true;
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return false;
    }
}