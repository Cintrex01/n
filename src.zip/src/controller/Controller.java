package controller;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public abstract class Controller {
    
    protected File arquivo;
    protected DataInputStream lerArquivo;
    protected DataOutputStream escreverArquivo;
    protected String path;
    protected String fileName;
    
    public abstract void Caminho();
    
    public void iniciaArquivo(){
        Caminho();
        
        File caminho = new File(path);
        if(!caminho.exists()){
            caminho.mkdir();
        }
        arquivo = new File(caminho, fileName);
        try {
            arquivo.createNewFile();
        } catch (IOException ex) {
            
        }
    }
    
    public void leituraArquivo(){
        if(arquivo == null){
            iniciaArquivo();
        }
        try {
            lerArquivo = new DataInputStream(new FileInputStream(arquivo));
        } catch (FileNotFoundException ex) {
        }
    }
    
    public void escritaArquivo(){
        if(arquivo == null){
            iniciaArquivo();
        }
        try {
            escreverArquivo = new DataOutputStream(new FileOutputStream(arquivo, true));
        } catch(IOException ex){
        }
    }
    
    public void escritaArquivoNovo(){
        if(arquivo == null){
            iniciaArquivo();
        }
        try {
            escreverArquivo = new DataOutputStream(new FileOutputStream(arquivo, false));
        } catch (IOException ex){
        }
    }
    
    public String leituraLinha(){
        if(lerArquivo == null){
            leituraArquivo();
        }
        try {
            return lerArquivo.readUTF();
        } catch(IOException ex){
        }
        return "Erro";
    }
    
    public void escritaTexto(String texto){
        if(escreverArquivo == null){
            escritaArquivo();
        }
        try {
            escreverArquivo.writeUTF(texto);
            escreverArquivo.flush();
        } catch (IOException ex){
        }
    }
}