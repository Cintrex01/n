package controller;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import model.Carro;

public class ControllerCarro extends Controller {

    @Override
    public void Caminho() {
        path = "C:\\Docs";
        fileName = "Carros.bin"; 
    }

    public ArrayList<Carro> exibirCarros() {
        ArrayList<Carro> dados = new ArrayList<>();

        leituraArquivo();

        try (DataInputStream dis = new DataInputStream(new FileInputStream(arquivo))) {
            while (dis.available() > 0) {
                String placa = dis.readUTF();
                String marca = dis.readUTF();
                String modelo = dis.readUTF();
                int potencia = dis.readInt();
                dados.add(new Carro(placa, marca, modelo, potencia));
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return dados;
    }

    public boolean carroExiste(String placa) {
        for (Carro carro : exibirCarros()) {
            if (carro.getPlaca().equals(placa)) {
                return true;
            }
        }
        return false;
    }

    public void cadastrarCarro(Carro carro) {
        escritaArquivo();

        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(arquivo, true))) {
            dos.writeUTF(carro.getPlaca());
            dos.writeUTF(carro.getMarca());
            dos.writeUTF(carro.getModelo());
            dos.writeInt(carro.getPotencia());
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public boolean alterarCarro(String placaAntiga, String placaNova, String marcaNova, String modeloNovo, int potenciaNova) {
        ArrayList<Carro> temporario = new ArrayList<>();

        leituraArquivo();

        try (DataInputStream dis = new DataInputStream(new FileInputStream(arquivo))) {
            while (dis.available() > 0) {
                String placa = dis.readUTF();
                String marca = dis.readUTF();
                String modelo = dis.readUTF();
                int potencia = dis.readInt();

                if (placaAntiga.equals(placa)) {
                    temporario.add(new Carro(placaNova, marcaNova, modeloNovo, potenciaNova));
                } else {
                    temporario.add(new Carro(placa, marca, modelo, potencia));
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        escritaArquivoNovo();

        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(arquivo))) {
            for (Carro carro : temporario) {
                dos.writeUTF(carro.getPlaca());
                dos.writeUTF(carro.getMarca());
                dos.writeUTF(carro.getModelo());
                dos.writeInt(carro.getPotencia());
            }
            return true;
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return false;
    }

    public boolean excluirCarro(String placa) {
        ArrayList<Carro> temporario = new ArrayList<>();

        leituraArquivo();

        try (DataInputStream dis = new DataInputStream(new FileInputStream(arquivo))) {
            while (dis.available() > 0) {
                String placaAtual = dis.readUTF();
                String marca = dis.readUTF();
                String modelo = dis.readUTF();
                int potencia = dis.readInt();

                if (!placa.equals(placaAtual)) {
                    temporario.add(new Carro(placaAtual, marca, modelo, potencia));
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        escritaArquivoNovo();

        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(arquivo))) {
            for (Carro carro : temporario) {
                dos.writeUTF(carro.getPlaca());
                dos.writeUTF(carro.getMarca());
                dos.writeUTF(carro.getModelo());
                dos.writeInt(carro.getPotencia());
            }
            return true;
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return false;
    }
}