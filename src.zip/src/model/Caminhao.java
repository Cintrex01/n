package model;

/**
 *
 * @author Lucas
 */
public class Caminhao {
    
    protected String placa;
    protected String marca;
    protected String modelo;
    protected int cargaMaxima;
    
    public Caminhao(String placa, String marca, String modelo, int cargaMaxima){
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.cargaMaxima = cargaMaxima;
    }

    /**
     * @return the placa
     */
    public String getPlaca() {
        return placa;
    }

    /**
     * @param placa the placa to set
     */
    public void setPlaca(String placa) {
        this.placa = placa;
    }

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * @return the cargaMaxima
     */
    public int getCargaMaxima() {
        return cargaMaxima;
    }

    /**
     * @param cargaMaxima the cargaMaxima to set
     */
    public void setCargaMaxima(int cargaMaxima) {
        this.cargaMaxima = cargaMaxima;
    }
    
    
    
}
